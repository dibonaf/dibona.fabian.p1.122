
package dibona.fabian.p1.pkg122;



public class Postre extends Plato implements Decorable {
    
    private boolean contieneAzucar;

    public Postre(String nombre, float precio, TipoPreparacion tipoDePreparacion, boolean contieneAzucar) {
        super(nombre, precio, tipoDePreparacion);
        this.contieneAzucar = contieneAzucar;
    }
    
    @Override
    public void decorar () {
        System.out.println("Decorando postre: " + getNombre());
    }
    
    @Override
    public String toString () {
        String azucar = contieneAzucar ? "SI" : "NO";
        return "POSTRE" + super.toString() + ", Contiene Azucar: " + azucar;
    }
    
}
