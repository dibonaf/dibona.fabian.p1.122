package dibona.fabian.p1.pkg122;

import java.util.Objects;

public abstract class Plato {
    
    private String nombre;
    private float precio;
    private TipoPreparacion tipoDePreparacion;

    public Plato(String nombre, float precio, TipoPreparacion tipoDePreparacion) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipoDePreparacion = tipoDePreparacion;
    }

    public String getNombre() {
        return nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public TipoPreparacion getTipoDePreparacion() {
        return tipoDePreparacion;
    }
    
    public String getTipoPlato() {
        return this.getClass().getSimpleName();
    }
    
    @Override
    public String toString() {
        return " - Nombre: " + nombre +
                ", Precio: $" + precio +
                ", Preparacion: " + tipoDePreparacion;
    }
    
    @Override
    public boolean equals (Object o){                
        if (this == o) 
            return true;
        if (o == null || getClass() != o.getClass()) 
            return false;
        
        Plato plato = (Plato) o;
        return nombre.equalsIgnoreCase(plato.nombre);
        
    }


    
}
