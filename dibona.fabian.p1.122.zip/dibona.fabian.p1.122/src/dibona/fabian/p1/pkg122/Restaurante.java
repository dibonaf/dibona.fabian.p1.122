package dibona.fabian.p1.pkg122;

import java.util.ArrayList;
import java.util.List;


public class Restaurante {
    
    private String nombre;
    private List <Plato> platos;
    
    public Restaurante(String nombre) {
        this.nombre = nombre;
        this.platos = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    
        
    public void agregarPlato (Plato plato) throws PlatoDuplicadoException {
        if (platos.contains(plato)) {
            throw new PlatoDuplicadoException ("Error! Ya existe un plato de tipo '"+
                                                plato.getTipoPlato() + "' con el nombre '" +
                                                plato.getNombre() + "'.");
        }
        platos.add(plato);
        System.out.println("Plato agregado: " + plato.getNombre());
    }
    
    public void mostrarPlatos() {
        System.out.println("\n--- Menu Completo de " + this.nombre + " ---");
        if (platos.isEmpty()) {
            System.out.println("El restaurante todavia no tiene platos registrados.");
            return;
        }
        for (Plato plato : platos) {
            System.out.println(plato.toString());
        }
        System.out.println("--------------------------------------");
    }
    
    
    public void prepararPlato (String nombrePlato) {
        Plato plato = buscarPlatoPorNombre(nombrePlato);
        if (plato == null) {
            System.out.println("Error! No se encontro el plato '" + nombrePlato + "'.");
            return;
        }
        if (plato instanceof Preparable) {
            ((Preparable) plato).preparar();
        } else {
            System.out.println("ATENCION! El plato '" + nombrePlato +
                                "' (" + plato.getTipoPlato() + ") no se puede preparar.");
        }
    }
    
    public void decorarPlato(String nombrePlato) {
        Plato plato = buscarPlatoPorNombre(nombrePlato);
        if (plato == null) {
            System.out.println("Error! No se encontro el plato '" + nombrePlato + "'.");
            return;
        } 
        if (plato instanceof Decorable) {
            ((Decorable) plato).decorar();
        } else {
            System.out.println("ATENCION! El plato '" + nombrePlato +
                                "' (" + plato.getTipoPlato() + ") no se puede decorar.");
        }
    }
    
    public List<Plato> filtrarPorTipoPreparacion (TipoPreparacion tipo) {
        System.out.println("\n--- Platos con preparacion " + tipo + "---");
        List<Plato> filtrados = new ArrayList<>();
        for (Plato plato : platos) {
            if (plato.getTipoDePreparacion() == tipo) {
                filtrados.add(plato);
                System.out.println(plato.toString());
            }
        }
        if (filtrados.isEmpty()) {
            System.out.println("No se encontraron platos de tipo " + tipo);
        }
        System.out.println("------------------------------------------");
        return filtrados;        
    }
    
    public void mostrarPlatosPorTipo (String tipoPlato) {
        System.out.println("\n--- Mostrando solo: " + tipoPlato + "s ---");
        int cont = 0;
        for (Plato plato : platos) {
            if (plato.getTipoPlato().equalsIgnoreCase(tipoPlato)) {
                System.out.println(plato.toString());
                cont++;
            }
        }
        if (cont == 0) {
            System.out.println("No se encontraron platos de tipo '" + tipoPlato + "'.");
        }
        System.out.println("--------------------------------------");
        }
    
    private Plato buscarPlatoPorNombre(String nombre) {
        for (Plato plato : platos) {
            if (plato.getNombre().equalsIgnoreCase(nombre)) {
                return plato;
            }
        }
        return null;
    }
}
