package dibona.fabian.p1.pkg122;


public interface Decorable {
    
    void decorar();
    
}
