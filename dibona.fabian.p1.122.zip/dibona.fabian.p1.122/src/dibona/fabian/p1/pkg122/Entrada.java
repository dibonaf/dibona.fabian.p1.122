package dibona.fabian.p1.pkg122;

public class Entrada  extends Plato implements Preparable, Decorable {
    
    private int cantidadIngredientes;

    public Entrada(String nombre, float precio, TipoPreparacion tipoDePreparacion, int cantidadIngredientes) {
        super(nombre, precio, tipoDePreparacion);
        this.cantidadIngredientes = cantidadIngredientes;
    }
    
    @Override
    public void preparar () {
        System.out.println("Preparando entrada: " + getNombre());
    }
    
    @Override
    public void decorar () {
        System.out.println("Decorando entrada: " + getNombre());
    }
    
    @Override
    public String toString () {
        return "ENTRADA" + super.toString() + ", Ingredientes: " + cantidadIngredientes;
    }
}
