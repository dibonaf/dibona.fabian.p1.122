
package dibona.fabian.p1.pkg122;


public enum TipoPreparacion {
    
    FRIA,
    CALIENTE
}
