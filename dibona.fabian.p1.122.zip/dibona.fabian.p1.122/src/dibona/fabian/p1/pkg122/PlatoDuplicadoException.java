
package dibona.fabian.p1.pkg122;


public class PlatoDuplicadoException extends Exception {

    public PlatoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
