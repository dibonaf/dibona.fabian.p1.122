
package dibona.fabian.p1.pkg122;

public class DibonaFabianP1122 {

    
    public static void main(String[] args) throws PlatoDuplicadoException {
        
        Restaurante miRestaurante = new Restaurante("La cocina del Rojo");
        
        System.out.println("==== AGREGANDO PLATOS ====");
        miRestaurante.agregarPlato(new Entrada("Bruschetta", 4500, TipoPreparacion.FRIA, 5));
        miRestaurante.agregarPlato(new Entrada("Provoleta", 8000, TipoPreparacion.CALIENTE, 3));
        miRestaurante.agregarPlato(new PlatoPrincipal("Bife de Chorizo", 20500, TipoPreparacion.CALIENTE, 25));
        miRestaurante.agregarPlato(new PlatoPrincipal("Ensalada Cesar", 3000, TipoPreparacion.FRIA, 10));
        miRestaurante.agregarPlato(new Postre("Budin de pan  mixto", 1800, TipoPreparacion.FRIA, true));
        miRestaurante.agregarPlato(new Postre("Volcan de Chocolate", 2200, TipoPreparacion.CALIENTE, true));

        
        System.out.println("\nIntentando agregar 'Bruschetta' de nuevo...");
        
      
        miRestaurante.mostrarPlatos();

        
        System.out.println("\n===== PREPARACION Y DECORACION =====");
        System.out.println("--- Preparando ---");
        miRestaurante.prepararPlato("Bruschetta");    
        miRestaurante.prepararPlato("Bife de Chorizo"); 
        miRestaurante.prepararPlato("Budin de pan  mixto"); 

        System.out.println("\n--- Decorando ---");
        miRestaurante.decorarPlato("Bruschetta");  
        miRestaurante.decorarPlato("Budin de pan  mixto"); 
        miRestaurante.decorarPlato("Bife de Chorizo"); 

        miRestaurante.filtrarPorTipoPreparacion(TipoPreparacion.CALIENTE);
        miRestaurante.filtrarPorTipoPreparacion(TipoPreparacion.FRIA);
        
        miRestaurante.mostrarPlatosPorTipo("Entrada");
        miRestaurante.mostrarPlatosPorTipo("PlatoPrincipal");
        miRestaurante.mostrarPlatosPorTipo("Postre");
        
            
        }
     
    }
    
