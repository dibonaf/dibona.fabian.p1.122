/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dibona.fabian.p1.pkg122;

/**
 *
 * @author fabi_
 */
public class PlatoPrincipal  extends Plato implements Preparable{
    
    private int tiempoCoccion;

    public PlatoPrincipal(String nombre, float precio, TipoPreparacion tipoDePreparacion, int tiempoCoccion) {
        super(nombre, precio, tipoDePreparacion);
        this.tiempoCoccion = tiempoCoccion;
    }
    
    @Override
    public void preparar () {
        System.out.println("Cocinando plato principal: " + getNombre() + " (" + tiempoCoccion + " min)");
    }
    
    @Override
    public String toString () {
        return "PLATO PRINCIPAL" + super.toString() + ", Coccion: " +  tiempoCoccion + " min";
    }    
       
}
