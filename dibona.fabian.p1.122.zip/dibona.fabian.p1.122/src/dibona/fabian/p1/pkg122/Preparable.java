
package dibona.fabian.p1.pkg122;

public interface Preparable {
    
    void preparar();
}
